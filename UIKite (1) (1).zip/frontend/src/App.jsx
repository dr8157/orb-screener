import React, { useState } from 'react';
import { useWebSocket } from './hooks/useWebSocket';
import { useClock } from './hooks/useClock';
import { useConfig } from './hooks/useConfig';
import { API_ENDPOINTS } from './utils/constants';
import Navbar from './components/Navigation/Navbar';
import RankingsTable from './components/Table/RankingsTable';
import AdminModal from './components/Admin/AdminModal';
import './App.css';

/**
 * ORB Institutional Screener - Main Application
 */
function App() {
  const [showAdmin, setShowAdmin] = useState(false);
  const [selectedInterval, setSelectedInterval] = useState('5m');

  // Convert interval to milliseconds
  const getIntervalMs = (interval) => {
    switch (interval) {
      case '1m': return 60000;  // 1 minute
      case '5m': return 5000;   // 5 seconds (more responsive for 5m view)
      case '15m': return 15000; // 15 seconds
      default: return 5000;
    }
  };

  // Hooks
  const {
    signals,
    isConnected,
    isConnecting,
    error,
    lastUpdate,
    reconnect
  } = useWebSocket(getIntervalMs(selectedInterval));

  const currentTime = useClock(1000);
  const { config, updateConfig, resetConfig, isLoading: configLoading } = useConfig();

  // Handle baseline refresh
  const handleRefreshBaselines = async () => {
    try {
      const response = await fetch(API_ENDPOINTS.baselineRefresh, {
        method: 'POST',
      });
      if (response.ok) {
        console.log('✓ Baselines refreshed');
      }
    } catch (err) {
      console.error('Failed to refresh baselines:', err);
    }
  };

  // Handle logout (placeholder)
  const handleLogout = () => {
    console.log('Logout clicked');
  };

  return (
    <div className="min-h-screen">
      {/* Navbar */}
      <Navbar
        isConnected={isConnected}
        isConnecting={isConnecting}
        error={error}
        currentTime={currentTime}
        selectedInterval={selectedInterval}
        onIntervalChange={setSelectedInterval}
        onRefreshBaselines={handleRefreshBaselines}
        onAdminClick={() => setShowAdmin(true)}
        onLogout={handleLogout}
        onReconnect={reconnect}
      />

      {/* Main Content */}
      <main className="max-w-[1800px] mx-auto px-3 sm:px-4 md:px-6 py-4 sm:py-6">
        <RankingsTable
          signals={signals}
          isConnected={isConnected}
          lastUpdate={lastUpdate}
        />
      </main>

      {/* Admin Modal */}
      {showAdmin && (
        <AdminModal
          config={config}
          onClose={() => setShowAdmin(false)}
          onSave={updateConfig}
          onReset={resetConfig}
          isLoading={configLoading}
        />
      )}
    </div>
  );
}

export default App;
